// Fungsi untuk mengaktifkan dan menonaktifkan mode gelap
function ubahTema() {
  document.body.classList.toggle("dark");
}
